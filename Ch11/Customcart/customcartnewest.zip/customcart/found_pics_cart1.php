<?php
//session_start();
//if (!isset($_SESSION['user_id'])){
//header('location:login.php');
//exit();
//}
$menu = 2;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Template for an interactive web page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap CSS File -->
  <link rel="stylesheet" 
  href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" 
  integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" 
  crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="transparent.css">
</head>
<body>
<div class="container" style="margin-top:10px">
<!-- Header Section -->
<header class="jumbotron text-center row mx-auto"
style="width:90%; height:auto; background:#95b522; margin-bottom: 0px; padding:0px;"> 
<?php include('includes/header_add_painting1.php'); ?>
</header>
<!-- Body Section -->
<div class="content mx-auto" style="background-color:transparent; ;margin-top: -17px; border:10px white solid; width: 90%; ">
  <div class="row mx-auto" style="padding-left: 0px; height: auto;">
<!-- Center Column Content Section -->
  <div class="col-sm-14 text-center float-center" style="padding:20px; margin-top: 5px;">
<h3 style="color: white;">To buy a painting please click its Add to Cart link</h3>
<?php
require("process_found_pics.php");
?>
<p style="color:white">No paintings displayed? Either we have nothing that matches your requirements at the moment OR<br>you may have forgotten to select 
BOTH the search fields. Please click the Home Page button and try again.</p>
<footer style="color:white;">
<?php include("includes/footer.inc"); ?>
</footer>
</div><!--End of content-->

</div>
</div>
</div>
</body>
</html>