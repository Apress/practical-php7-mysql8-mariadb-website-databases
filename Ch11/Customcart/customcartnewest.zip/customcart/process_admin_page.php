<?php
	$errors = array(); // Set an error array.
// Has an artist's first name been entered?
    $first_name = trim($_POST['first_name']);
	if (empty($first_name)) {
		$errors[] = 'You forgot to enter the artist\'s first name';
	}
// Has an artist's middle name been entered?
    $middle_name = trim($_POST['middle_name']);
	if (empty($middle_name)) {
		$errors[] = 'You forgot to enter the artist\'s middle name';
	} 
// Has the artist's last name been entered?
    $last_name = trim($_POST['last_name']);
	if (empty($last_name)) {
		$errors[] = 'You forgot to enter the artist\'s last name';
	} 
if (empty($errors)) { // If the wuery ran OK
	// Register the artist in the database
	
	try {
		require ('mysqli_connect.php'); // Connect to the db.
		// Make the query:
		$query = "INSERT INTO artists (artist_id, first_name, middle_name, last_name) ";
        $query .= "VALUES ";
	    $query .= "(' ',?,?,?)"; 
        $q = mysqli_stmt_init($dbcon);
        mysqli_stmt_prepare($q, $query);
        // use prepared statement to insure that only text is inserted
        // bind fields to SQL Statement
        mysqli_stmt_bind_param($q, 'sss', $first_name, $middle_name, $last_name);
        // execute query
        mysqli_stmt_execute($q);
        if (mysqli_stmt_affected_rows($q) == 1) {		
		echo '<h2>The artist was successfully added. Add another one?</h2><br>';
		} else { // If the query failed to run
		// Message:
			echo '<h2>System Error</h2>
			<p class="error">The artist could not be added due to a system error. We apologize for any inconvenience.</p>'; 
			// Debugging message:
			echo '<p>' . mysqli_error($dbcon) . '<br><br>Query: ' . $q . '</p>';
		} // End of if ($result)
		mysqli_close($dbcon); // Close the database connection
	}
catch(Exception $e)
{
	print "The system is busy, please try later";
    //print "An Exception occurred. Message: " . $e->getMessage();
}
catch(Error $e)
{
	print "The system is busy, please come back later";
    //print "An Error occurred. Message: " . $e->getMessage();
}
	} else { // Display any errors
		echo '<h2>Error!</h2>
		<p class="error">The following error(s) occurred:<br>';
		foreach ($errors as $msg) { // Dispaly any errors
			echo " - $msg<br>\n";
		}
		echo '</p><h3>Please try again.</h3><p><br></p>';
		}// End of if error checks
} // End of the conditionals
?>