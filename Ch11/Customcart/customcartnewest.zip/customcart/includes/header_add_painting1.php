<div class="col-sm-2" >
<img class="img-fluid" style="padding-top: 5px; height=200" src="images/dove-1.png" alt="dove"> 
</div>
<div class="col-sm-8" style="color :white; padding-top: 5%;">
 <div class="h1 mb-2 font-bold text-left" >The Dove Gallery</div>
 <p class='lead text-center'>Affordable Original Paintings</p>
</div>
<div class="col-sm-2" style="padding-top: 10px; padding-bottom: 10px;">
     <nav>
	 <div class="btn-group-vertical btn-group-sm float-right" style="width: 140px;" role="group" aria-label="Button Group">
	 <?php if($menu == 1) { ?>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="admin_add_painting.php" role="button">Add Another</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="admin_page.php" role="button">Add Artist</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="#" role="button">View Orders</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="#" role="button">New Password</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="Logout.php" role="button">Logout</a>
	 <?php } 
	 else {
		 if($menu == 2) { ?>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="cart.php" role="button">View Cart</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="index.php" role="button">Home Page</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="Logout.php" role="button">Logout</a>
	 <?php }
	 else {
		 if($menu == 3) { ?>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="admin-page.php" role="button">Add Another</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="admin_add_painting.php" role="button">Add Painting</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="#" role="button">View Orders</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="#" role="button">New Password</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="Logout.php" role="button">Logout</a>
      <?php }
	 else {
		 if($menu == 4) { ?>
	  <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="register.php" role="button">Register</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="Login.php" role="button">Login</a>
	   <?php }
	 else {
	     if($menu == 7) { ?>
		  <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="register.php" role="button">Register</a>
		 <?php }
	 else if($menu == 8) { ?>
	      <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="register.php" role="button">Erase</a>
		 <?php }
     else {
		 if($menu == 9) { ?>
		 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="Login.php" role="button">Login</a>	 
	 <?php 
	 } } } } } } ?>
	 </div>
    </nav>
	</div>