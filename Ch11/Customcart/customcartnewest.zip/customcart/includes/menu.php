<div style="padding-top: 10px; padding-bottom: 10px;">
     <nav>
	  <div class="btn-group-vertical btn-group-sm float-right" style="width: 140px;" role="group" aria-label="Button Group">
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="#" role="button">About Us</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="#" role="button">FAQs</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="#" role="button">Contact Us</a>
	 <a class="btn btn-primary" style="background:#559a55; border: 5px outset #559a55;" href="index.php" role="button">Home Page</a>
	 </div>
    </nav>
	</div>