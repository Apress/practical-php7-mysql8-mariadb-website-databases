<?php
//Connect to the database
try {
require ( 'mysqli_connect.php' ) ;
// Select the first thre items items from the art table
$q = "SELECT * FROM art LIMIT 3";
$result = mysqli_query( $dbcon, $q ) ;
if ( mysqli_num_rows( $result ) > 0 )
{
// Table header
echo '<table class="table table-striped" style="background: white;">
<tr><th scope="col">Thumb</th><th scope="col">Type</th>
<th scope="col">Medium</th><th scope="col">Artist</th>
<th scope="col">Details</th><th scope="col">Price &pound;</th>
</tr>';		
// Fetch the matching records and populate the table display
while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
	echo '<tr>
	<td><img src='.$row['thumb'] . '></td>
	<td>' . $row['type'] . '</td>
	<td>' . $row['medium'] . '</td>
	<td>' . $row['artist'] . '</td>
	<td>' . $row['mini_descr'] . '</td>
	<td>' . $row['price'] . 
	'<br><a href="added.php?id=' . $row['art_id'] . '">Add to Cart</a></td>
	</tr>';
	}
	echo '</table>'; // End of table
// Close the database connection.
  mysqli_close( $dbcon ) ; 
}
// Or notify the user that no matching paintings were found
else { echo '<p>There are currently no items matching your search criteria.</p>' ; }
}
catch(Exception $e)
{
	print "The system is busy, please try later";
    //print "An Exception occurred. Message: " . $e->getMessage();
}catch(Error $e)
{
	print "The system is busy, please come back later";
    //print "An Error occurred. Message: " . $e->getMessage();
}
?>