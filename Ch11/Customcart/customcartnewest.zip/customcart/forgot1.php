<?php
$menu = 5;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Template for an interactive web page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap CSS File -->
  <link rel="stylesheet" 
  href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" 
  integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" 
  crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="transparent.css">
</head>
<body>
<div class="container" style="margin-top:10px">
<!-- Header Section -->
<header class="jumbotron text-center row mx-auto"
style="width:90%; height:auto; background:#95b522; margin-bottom: 0px; padding:0px;"> 
<?php include('includes/header_add_painting1.php'); ?>
</header>
<!-- Body Section -->
<div class="content mx-auto" style="background-color:transparent; ;margin-top: -17px; border:10px white solid; color: white; width: 90%; ">
  <div class="row mx-auto" style="padding-left: 0px; height: auto;">
<!-- Center Column Content Section -->
  <div class="col-sm-10 text-center" style="padding:0px; margin-top: 5px;">
	<!--Start of admin add paintings content-->
<?php
// This code is a query that INSERTs a paintings in the art table
// Confirm that form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	require("process_forgot.php");
}
?>
<form  action="forgot1.php" method="post">
<div class="form-group row">
    <label class="col-sm-4 col-form-label"></label>
    <div class="col-sm-6">
<h2 style="margin-top: 10px;">Forgot Your Password?</h2>
<h6>When you apply, you will receive your new password in an email. Read that 
email as soon as possible. Don't delay! For 
maximum security, immediately login with your new password. Then change the 
password as quickly as possible.</h6>  
</div>
</div>
<div class="form-group row">
    <label for="email" class="col-sm-4 col-form-label text-right">Your email address:</label>
    <div class="col-sm-6">
      <input type="text" class="form-control" id="email" name="email" 
	  placeholder="Email" maxlength="30" required
	  value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>" >
    </div>
  </div>
  <div class="form-group row">
  <label class="col-sm-4 col-form-label"></label>
  <div class="col-sm-6">
<input id="submit" class="btn btn-primary" style="margin: 0px; background:#559a55; border: 5px outset #559a55; width: 140px;" type="submit" name="submit" value="Submit">
</div>
</div>
<div class="form-group row">
  <label class="col-sm-4 col-form-label"></label>
  <div class="col-sm-6">
<footer class="jumbotron row"
style="background:#68CE53; padding-top: 5px; padding-bottom: 5px; margin: 0px;">
  <?php include('includes/footer.php'); ?>
</footer>
</div>
</div>
</form><!--End of the add a painting content-->
</div>
<!-- Right-side Column Content Section -->
	<aside class="col-sm-2" style="padding-top: 10px; padding-bottom: 10px;">
      <?php include('includes/menu1.php'); ?> 
	</aside>
	</div>
</div>
</div>
</body>
</html>